### Hexlet tests and linter status:
[![Actions Status](https://github.com/AstrellaNe/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AstrellaNe/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5b708b6a35bdd06dc8d4/maintainability)](https://codeclimate.com/github/AstrellaNe/python-project-49/maintainability)


**Presentation of Brain Even or Odd gameplay**
[![asciicast](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM.svg)](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM)

**Presentation of Brain Calculator gameplay**
[![asciicast](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ.svg)](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ)

**Presentation of Brain Main Module operation**
[![asciicast](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct.svg)](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct)