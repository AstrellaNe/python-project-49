# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_start:main',
                     'brain-gcd = brain_games.games.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AstrellaNe/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AstrellaNe/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/5b708b6a35bdd06dc8d4/maintainability)](https://codeclimate.com/github/AstrellaNe/python-project-49/maintainability)\n\n\n**Presentation of Brain Even or Odd gameplay**\n[![asciicast](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM.svg)](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM)\n\n**Presentation of Brain Calculator gameplay**\n[![asciicast](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ.svg)](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ)\n\n**Presentation of Brain Main Module operation**\n[![asciicast](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct.svg)](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct)',
    'author': 'Astrella.Ne',
    'author_email': 'mycuttingapp@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
