# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_start:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-prog = brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.1',
    'description': 'A set of 5 math mini-games. 3 correct answers to win. Any wrong - you lose.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AstrellaNe/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AstrellaNe/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/5b708b6a35bdd06dc8d4/maintainability)](https://codeclimate.com/github/AstrellaNe/python-project-49/maintainability)\n\n\n\n# Brain Games\n\nBrain Games - это набор из 5 простых математических игр для тренировки мозга или расслабления.\n\n## Игры\n\n\n1. **Brain Even**: Ответьте, является ли число четным. Игра дает случайно число.\\\n Необходимо ответить yes (если четное) или no (если нечетное).\\\nВводить только слова \'yes\' или \'no\'.\\\n\n2. **Brain Calc**: Решите арифметическую задачу ("+", "-" или "*").\\\nРешите простой пример. Игра дает два случайных числа и операцию над ними.\\\nАрифметическая операция выбирается случайным образом.\\\nВводить только цифры.\\\n\n3. **Brain GCD**: Найдите **наибольший** общий делитель двух чисел (НОД).\\\nИгра дает два случайных числа. Найдите их **наибольший** общий делитель.\\\nВводить только цифры.\\\n\n4. **Brain Progression**: Найдите пропущенное число в арифметической прогрессии.\\\nНайдите скрытое с помощью __**__ число в прогрессии. Прогрессия формируется случайным образом \\\nВводить только цифры.\\\n\n5. **Brain Prime**: Ответьте, является ли число простым.\\\nтветьте, является ли число простым. Игра дает случайно число. Необходимо ответить yes (если четное) или no (если нечетное).\\\nВводить только слова \'yes\' или \'no\'.\\\n\n### Логика игры\nИгра строится следующим образом:\n1. Игроку дается 3 вопроса.\n2. Игрок вводит ответы с клавиатуры (цифры или буквы, в зависимости от игры)\n3. При 3х верных ответах игра считается пройденной и заканчивается.\n4. При любом неверном ответе игра мгновенно прекращается.\n\n## Требования\n# Сборка осуществлена на Python 3.10. Ожидается, что основной фукнционал игр будет работать и на версиях от 3.6, однако работоспособность на версиях ниже 3.10 не проверялась.\\\n- Python 3.6 и выше\\\n- Poetry (если вы хотите использовать код для изменения, разработки или тестирования)\\\n\n\n\n## Установка для простого использования\n1. Клонируйте репозиторий с играми:\\\n\n    git clone https://github.com/AstrellaNe/python-project-49\\\n\n2. Перейдите в директорию с играми (из той директории, в которую клонировали репозиторий):\\\n\n    cd brain_games\\\n\n3. Установите пакет игр из директории brain_games:\\\n\n ### make package-install  (из локальной директории репозитория brain_games)\\\n\n    _Примечание: эта команда использует метод pip install --user_\\\n    \nили\n\n### make package-reinstall (для перестустановки с --force)\\\n\n    _Примечание: Если вы установили пакет игр правильно (через \'pip install --user\'), все команды должны работать с помощью команд напрямую из директории игр._\\\n    _Например, для запуска игры Brain Calc внутри директории brain_games используйте команду \'brain-calc\'._\\\n\n#### Список команд:\n- `brain-games`: Запуск набора игр.\n- `brain-even`: Запуск игры "Brain Even".\n- `brain-calc`: Запуск игры "Brain Calc".\n- `brain-gcd`: Запуск игры "Brain GCD".\n- `brain-prog`: Запуск игры "Brain Progression".\n- `brain-prime`: Запуск игры "Brain Prime".\n\n\n\n\n## Установка для разработчика\n\n1. Установите Poetry, если его у вас еще нет:\n\n   curl -sSL https://install.python-poetry.org | python3 -\n\n2. Клонируйте репозиторий с играми в желаемую директорию:\n\n    git clone https://github.com/your-username/brain-games.git\n\n3. Перейдите в директорию с играми:\n\n    cd директория/brain-games\n\n4. Установите зависимости: (для разработчиков и тестировщиков)\n\n    poetry install\n\n5. Установите пакет игр:\n\n    make package-install\nили\n    make package-reinstall (для перестустановки с --force)\n\n\n\n**Brain Games Installation and Operation check**\n[![asciicast](https://asciinema.org/a/ITIguCrnkFxIdJ99E9CkGI8gH.svg)](https://asciinema.org/a/ITIguCrnkFxIdJ99E9CkGI8gH)\n\n**Presentation of Brain Even or Odd gameplay**\n[![asciicast](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM.svg)](https://asciinema.org/a/RRiq04vt5LzNhf46gis52RokM)\n\n**Presentation of Brain Calculator gameplay**\n[![asciicast](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ.svg)](https://asciinema.org/a/hrZ59uKwTc9dUUhLWj7KHWHhQ)\n\n**Presentation of Brain GCD Module gameplay**\n[![asciicast](https://asciinema.org/a/pDiJAPqz7GD8lodbcdiWKDFCM.svg)](https://asciinema.org/a/pDiJAPqz7GD8lodbcdiWKDFCM)\n\n**Presentation of Brain Progression Module gameplay**\n[![asciicast](https://asciinema.org/a/COxgFbgiwHMKyYGaWuq16f0JA.svg)](https://asciinema.org/a/COxgFbgiwHMKyYGaWuq16f0JA)\n\n**Presentation of Brain Prime Number Module gameplay**\n[![asciicast](https://asciinema.org/a/gybjMHYq1m9zEsXveAfKBCMHV.svg)](https://asciinema.org/a/gybjMHYq1m9zEsXveAfKBCMHV)\n\n**Presentation of Brain Main Module operation**\n[![asciicast](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct.svg)](https://asciinema.org/a/vEWonqndJBFODsPgEQn7WF1Ct)',
    'author': 'Astrella.Ne',
    'author_email': 'mycuttingapp@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AstrellaNe/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
